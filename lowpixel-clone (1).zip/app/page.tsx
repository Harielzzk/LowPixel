import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ChevronDown, Users, Shield, Home } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Top Bar */}
      <div className="bg-slate-900 border-b border-slate-800 py-2 px-4">
        <div className="container mx-auto flex items-center justify-between text-sm">
          <div className="flex items-center space-x-6">
            <span className="text-gray-400">Servidores</span>
          </div>
          <div className="flex items-center space-x-4 text-gray-400">
            <span>Registrar-se</span>
            <span>Login</span>
            <span>Registrar-se</span>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="bg-slate-900/80 backdrop-blur-sm border-b border-slate-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-8">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-pink-500 to-purple-600 rounded flex items-center justify-center">
                  <span className="text-white font-bold text-sm">💎</span>
                </div>
                <span className="text-2xl font-bold text-white">lowpixel</span>
              </div>
              <nav className="hidden md:flex items-center space-x-8">
                <a href="#" className="text-gray-300 hover:text-white transition-colors font-medium">
                  Notícias
                </a>
                <a href="#" className="text-gray-300 hover:text-white transition-colors font-medium">
                  Como jogar
                </a>
                <a href="#" className="text-gray-300 hover:text-white transition-colors font-medium">
                  Aplicativo
                </a>
                <a href="#" className="text-gray-300 hover:text-white transition-colors font-medium">
                  Perguntas frequentes
                </a>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-400">
                <Users className="w-4 h-4" />
                <span>PLAYERS</span>
              </div>
              <Button className="bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white px-6 py-2 font-bold text-sm">
                JOGAR AGORA
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative min-h-[700px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-950 to-purple-950"></div>
        <div
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage: `url('/minecraft-gaming-world-dark-atmosphere.png')`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        ></div>

        <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 text-balance leading-tight">
            BEM-VINDO AO UNIVERSO
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-purple-400">LOWPIXEL</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-2xl mx-auto text-balance font-medium">
            ENTRE PARA A CIDADE, CRIE SEU LEGADO E VIVA INTENSAMENTE CADA MISSÃO.
            <br />O PRÓXIMO PROTAGONISTA PODE SER VOCÊ.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              variant="outline"
              className="border-gray-600 text-white hover:bg-gray-800 px-8 py-3 bg-transparent font-bold"
            >
              VER VÍDEO
            </Button>
            <Button className="bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white px-8 py-3 font-bold">
              COMO JOGAR?
            </Button>
          </div>
        </div>
      </section>

      {/* News Cards */}
      <section className="py-16 px-4 bg-slate-950">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            <Card className="bg-slate-900 border-slate-800 overflow-hidden hover:border-slate-700 transition-colors">
              <div className="p-6">
                <Badge className="bg-blue-600 text-white mb-4 font-bold">Anunciado</Badge>
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold">💎</span>
                  </div>
                  <span className="text-white font-bold">lowpixel</span>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">A beta do LowPixel chegou ao level!</h3>
                <p className="text-gray-400 text-sm">28 de junho de 2024</p>
              </div>
            </Card>

            <Card className="bg-slate-900 border-slate-800 overflow-hidden hover:border-slate-700 transition-colors">
              <div className="p-6">
                <Badge className="bg-purple-600 text-white mb-4 font-bold">Atualização</Badge>
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center">
                    <Home className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-white font-bold">lowpixel</span>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">A primeira temporada do LowPixel está chegando!</h3>
                <p className="text-gray-400 text-sm">28 de junho de 2024</p>
              </div>
            </Card>
          </div>

          <div className="text-center mt-8">
            <Button variant="link" className="text-gray-400 hover:text-white font-medium">
              VER MAIS NOVIDADES
              <ChevronDown className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Game Steps */}
      <section className="py-20 px-4 bg-slate-900">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div className="text-pink-400 text-lg font-bold mb-8">
                💎 Alguns escolhem o caminho fácil, outros lutam pelo que querem. No fim, só os mais espertos
                sobrevivem.
              </div>

              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="bg-gradient-to-r from-pink-500 to-pink-600 text-white rounded-full w-10 h-10 flex items-center justify-center font-bold text-lg flex-shrink-0">
                    1
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-3">Instalação</h3>
                    <p className="text-gray-300 text-lg leading-relaxed">
                      Após abrir o GTA San Andreas, baixe e instale a plataforma Multi Theft Auto (MTA). Clique abaixo
                      para começar.
                    </p>
                    <div className="mt-4 flex items-center space-x-2 text-sm text-gray-400">
                      <Shield className="w-4 h-4" />
                      <span>MULTI THEFT AUTO</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-gradient-to-r from-pink-500 to-pink-600 text-white rounded-full w-10 h-10 flex items-center justify-center font-bold text-lg flex-shrink-0">
                    2
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-3">Whitelist</h3>
                    <p className="text-gray-300 text-lg leading-relaxed">
                      Crie uma conta, faça a whitelist e aguarde a aprovação para acessar e conhecer uma comunidade
                      segura.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-gradient-to-r from-pink-500 to-pink-600 text-white rounded-full w-10 h-10 flex items-center justify-center font-bold text-lg flex-shrink-0">
                    3
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-3">Jogar</h3>
                    <p className="text-gray-300 text-lg leading-relaxed">
                      Procure nosso servidor na lista do Multi Theft Auto ou digite diretamente o IP na barra de
                      conexão. Se preferir, clique no botão abaixo para se conectar diretamente.
                    </p>
                  </div>
                </div>
              </div>

              <Button className="bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white px-8 py-3 font-bold text-lg">
                JOGAR AGORA
              </Button>
            </div>

            <div className="relative">
              <div
                className="w-full h-[500px] bg-slate-800 rounded-lg border border-slate-700"
                style={{
                  backgroundImage: `url('/game-map-interface-dark-gaming-ui.png')`,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                }}
              ></div>
            </div>
          </div>
        </div>
      </section>

      {/* Character Section */}
      <section className="py-20 px-4 bg-slate-950">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div
                className="w-full h-[500px] bg-slate-800 rounded-lg border border-slate-700"
                style={{
                  backgroundImage: `url('/game-characters-police-doctor-worker-roleplay.png')`,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                }}
              ></div>
            </div>

            <div className="space-y-6">
              <div className="text-pink-400 text-2xl font-bold">💎</div>
              <h2 className="text-4xl md:text-5xl font-bold text-white text-balance leading-tight">
                SEJA UM CIVIL E EXPLORE O LOWPIXEL
              </h2>
              <p className="text-gray-300 text-lg leading-relaxed">
                Divirta-se com uma experiência única no LowPixel, onde cada jogador pode ser um civil e explorar
                diversas profissões e atividades. Desde ser um médico dedicado, até se tornar um criminoso, as
                possibilidades são infinitas.
              </p>
              <Button className="bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white px-8 py-3 font-bold text-lg">
                JOGAR AGORA
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4 bg-slate-900">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-4xl font-bold text-white text-center mb-16">Perguntas frequentes</h2>

          <div className="space-y-4">
            {[
              "Como adquirir LowPoints (LP)?",
              "É possível pedir reembolso após a compra da LowPoint?",
              "Como entrar em contato no LowPixel?",
              "É possível resgatar um banimento no LowPixel?",
              "O que um novato deve fazer no LowPixel?",
              "Tenho sugestões legais para o LowPixel. Onde devo mandá-las?",
            ].map((question, index) => (
              <Card key={index} className="bg-slate-800 border-slate-700 hover:bg-slate-750 transition-colors">
                <div className="p-6 flex items-center justify-between cursor-pointer">
                  <span className="text-white font-medium text-lg">{question}</span>
                  <ChevronDown className="w-5 h-5 text-gray-400" />
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-800 py-12 px-4">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-6">
            <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-purple-600 rounded flex items-center justify-center">
              <span className="text-white font-bold">💎</span>
            </div>
            <span className="text-2xl font-bold text-white">lowpixel</span>
          </div>
          <p className="text-gray-400">© 2024 LowPixel. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  )
}
