import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import "./globals.css"

export const metadata: Metadata = {
  title: "LowPixel - Universo Gaming",
  description: "Entre para a cidade, crie seu legado e viva intensamente cada missão no LowPixel",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" className="dark">
      <body className={`font-sans antialiased ${GeistSans.variable} ${GeistMono.variable}`}>{children}</body>
    </html>
  )
}
